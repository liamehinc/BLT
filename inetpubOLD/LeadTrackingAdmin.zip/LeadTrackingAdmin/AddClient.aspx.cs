﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class AddChild : System.Web.UI.Page
{
    string connectionString = ConfigurationManager.ConnectionStrings["csLeadTrackingProgram2"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        //string connectionString = ConfigurationManager.ConnectionStrings["csLeadTrackingProgram2"].ConnectionString;

        Trace.Write("connectionString: " + connectionString);

        SqlConnection con = new SqlConnection(connectionString);

        string com = "Select Lastname, FamilyID from dbo.Family order by Lastname asc";

        SqlDataAdapter adpt = new SqlDataAdapter(com, con);

        DataTable dt = new DataTable();

        adpt.Fill(dt);

        FamilyNameList.DataSource = dt;

        FamilyNameList.DataBind();

        Random r1 = new Random();

        int addr = r1.Next(9999);
        int zip = r1.Next(99999);

        FamilyNameList.DataTextField = "Lastname";
        FamilyNameList.DataValueField = "FamilyID";
        FamilyNameList.DataBind();
        //FamilyNameList.("test");
        FamilyNameList.Items.Insert(0, "-");
        FamilyNameList.Items.Insert(1, "Bonifacic"  + " -- " + addr.ToString() + " Main St, " + zip.ToString());
        
        Trace.Write("connectionString: " + connectionString);

        SqlConnection conLang = new SqlConnection(connectionString);

        string comLang = "Select LanguageID,LanguageName from dbo.Language order by LanguageName asc";

        SqlDataAdapter adptLang = new SqlDataAdapter(comLang, conLang);

        DataTable dtLang = new DataTable();

        adptLang.Fill(dtLang);

        ddlLanguage.DataSource = dtLang;

        ddlLanguage.DataBind();

        ddlLanguage.DataTextField = "LanguageName";
        ddlLanguage.DataValueField = "LanguageID";
        
        ddlLanguage.DataBind();
        ddlLanguage.Items.Insert(0, "-");
        

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {

            lbOutput.Text = "";

            //string connectionString = "Data Source=PETRUCHIO;Initial Catalog=LeadTrackingProgram2;User ID=appUser;Password=Password1234";  // ConfigurationManager.ConnectionStrings["csLeadTrackingProgram2"].ConnectionString;

            //string connectionString = ConfigurationManager.ConnectionStrings["csLeadTrackingProgram2"].ConnectionString;

            lbOutput.Text = "Here: " + connectionString;

            SqlConnection sqlConnection = new SqlConnection(connectionString);
            SqlCommand command = new SqlCommand("usp_InsertPerson", sqlConnection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.Add("@FirstName", SqlDbType.VarChar).Value = tbFirstName.Text;
            command.Parameters.Add("@LastName", SqlDbType.VarChar).Value = FamilyNameList.Text;//tbLastName.Text;
            command.Parameters.Add("@BirthDate", SqlDbType.DateTime).Value = DateTime.Today;
            sqlConnection.Open();
        //    command.ExecuteNonQuery();
            sqlConnection.Close();

            lbOutput.Text = "New Research Subject Inserted at: " + DateTime.Now;

            Response.Redirect("Questionnaire.aspx");

        }
        catch (SqlException exSQL)
        {
            lbOutput.Text = "SQL ERROR: " + exSQL.Message.ToString() + DateTime.Now;
            Trace.Write("SQL Error" + exSQL.Message.ToString());

        }
        catch (Exception ex)
        {
            lbOutput.Text = "ERROR: " + ex.Message.ToString() + DateTime.Now;
            Trace.Write("Error" + ex.Message.ToString());
        }

    }
}