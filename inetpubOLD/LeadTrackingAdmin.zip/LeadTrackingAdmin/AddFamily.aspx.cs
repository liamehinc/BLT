﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Text;

public partial class AddFamily : System.Web.UI.Page
{
    string connectionString = ConfigurationManager.ConnectionStrings["csLeadTrackingProgram2"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        //updateLanguage();
    }

    protected void updateLanguage()
    {
        //string connectionString = ConfigurationManager.ConnectionStrings["csLeadTrackingProgram2"].ConnectionString;

        Trace.Write("connectionString: " + connectionString);

        SqlConnection con = new SqlConnection(connectionString);

        string com = "Select LanguageID,LanguageName from dbo.Language order by LanguageName asc";

        SqlDataAdapter adpt = new SqlDataAdapter(com, con);

        DataTable dt = new DataTable();

        adpt.Fill(dt);

        //ddlLanguage.DataSource = dt;

        //ddlLanguage.DataBind();

        //ddlLanguage.DataTextField = "LanguageName";

        //ddlLanguage.DataValueField = "LanguageID";
        //ddlLanguage.DataBind();
        //ddlLanguage.Items.Insert(0, "-");
        
    }

    protected void RefreshLanguage_Click(object sender, EventArgs e)
    {
        updateLanguage();
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {

            lbOutput.Text = "";

            //string connectionString = "Data Source=PETRUCHIO;Initial Catalog=LeadTrackingProgram2;User ID=appUser;Password=Password1234";  // ConfigurationManager.ConnectionStrings["csLeadTrackingProgram2"].ConnectionString;

           // string connectionString = ConfigurationManager.ConnectionStrings["csLeadTrackingProgram2"].ConnectionString;

            lbOutput.Text = "Here: " + connectionString;

            SqlConnection sqlConnection = new SqlConnection(connectionString);
            SqlCommand command = new SqlCommand("usp_AddNewFamilyWebScreen", sqlConnection);
            command.CommandType = CommandType.StoredProcedure;
           // command.Parameters.Add("@FirstName", SqlDbType.VarChar).Value = tbFirstName.Text;
            command.Parameters.Add("@FamilyLastName", SqlDbType.VarChar).Value = tbLastName.Text;
            command.Parameters.Add("@StreetNum", SqlDbType.VarChar).Value = TextBoxStreetNumber.Text;
            command.Parameters.Add("@StreetName", SqlDbType.VarChar).Value = TextBoxStreetName.Text;
            command.Parameters.Add("@StreetSuff", SqlDbType.VarChar).Value = DropDownListStreetSuffix.Text;
            command.Parameters.Add("@ApartmentNum", SqlDbType.VarChar).Value = TextBoxApartmentNumber.Text;
            command.Parameters.Add("@CityName", SqlDbType.VarChar).Value = TextBoxCity.Text;

            command.Parameters.Add("@StateAbbr", SqlDbType.VarChar).Value = ddlState.Text;
            command.Parameters.Add("@ZipCode", SqlDbType.VarChar).Value = TextBoxZip.Text;
            command.Parameters.Add("@HomePhone", SqlDbType.BigInt).Value = Convert.ToInt64(HomePhoneTextBox.Text);
            command.Parameters.Add("@WorkPhone", SqlDbType.BigInt).Value = Convert.ToInt64(WorkPhoneTextBox.Text);
     //     command.Parameters.Add("@Language", SqlDbType.TinyInt).Value = Convert.ToInt16(ddlLanguage.SelectedValue);
       //     command.Parameters.Add("@NumberofSmokers", SqlDbType.TinyInt).Value = Convert.ToInt16(DropDownListSmokers.SelectedValue);
            command.Parameters.Add("@Pets", SqlDbType.Bit).Value = Convert.ToInt16(RadioButtonListPets.SelectedValue);
            command.Parameters.Add("@inandout", SqlDbType.Bit).Value = Convert.ToInt16(RadioButtonListPetsInOut.SelectedValue);
           // command.Parameters.Add("@Occupation", SqlDbType.SmallInt).Value = ra
         //   command.Parameters.Add("@OccupationNotes", SqlDbType.VarChar).Value = TextBoxOccupationNotes.Text;
            command.Parameters.Add("@OtherNotes", SqlDbType.VarChar).Value = TextBoxOtherNotes.Text;
      
            sqlConnection.Open();
            command.ExecuteNonQuery();
            sqlConnection.Close();

            lbOutput.Text = "New Family Inserted at: " + DateTime.Now;

        }
        catch (SqlException exSQL)
        {
            lbOutput.Text = "SQL ERROR: " + exSQL.Message.ToString() + " "+ DateTime.Now;
            Trace.Write("SQL Error" + exSQL.Message.ToString());

        }
        catch (Exception ex)
        {
            lbOutput.Text = "ERROR: " + ex.Message.ToString() + " " + DateTime.Now;
            Trace.Write("Error" + ex.Message.ToString());
        }

    }
    protected void ddlLanguage_SelectedIndexChanged(object sender, EventArgs e)
    {
        updateLanguage();   
    }

    static byte[] GetBytes(string str)
    {
        byte[] bytes = new byte[str.Length * sizeof(char)];
        System.Buffer.BlockCopy(str.ToCharArray(), 0, bytes, 0, bytes.Length);
        return bytes;
    }

    static string GetString(byte[] bytes)
    {
        char[] chars = new char[bytes.Length / sizeof(char)];
        System.Buffer.BlockCopy(bytes, 0, chars, 0, bytes.Length);
        return new string(chars);
    }
}